package Shop;

import java.util.ArrayList;

public interface DepInter {
	public ArrayList<String> AddProduct();
}
